VWS frontend
